package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.obs.dto.PayeeTable;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;
//This class contains the methods implemented for Payee table
public class PayeeDaoImpl implements PayeeDao
{	Logger payeeLogger=null;
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	//adding a payee
	public boolean addPayee(PayeeTable payee)throws BankException
	{
		int dataInserted = 0;
		try{
			payeeLogger.info("Adding payee details");
			pst = con.prepareStatement(QueryMapper.ADD_PAYEE);
			pst.setLong(1,payee.getAccount_id());
			pst.setLong(2,payee.getPayee_account_id());
			pst.setString(3, payee.getNick_name());
			payeeLogger.warn("Payee details being added");
			dataInserted = pst.executeUpdate();
			payeeLogger.debug("Adding payee details to payeeList");
		}
		catch(Exception e)
		{
			payeeLogger.fatal("Bank Exception occured");
			throw new BankException("Exception occured while adding payee details");
		}
		
		if(dataInserted>0)
			return true;
		else
			return false;
	}

	//fetching a list payees
	public ArrayList<PayeeTable> getPayee(long accNo)throws BankException
	{
		ArrayList<PayeeTable> payeeList = new ArrayList<PayeeTable>();
		PayeeTable payee;
		try{
			payeeLogger.info("Fetching Payee details");
			pst = con.prepareStatement(QueryMapper.GET_PAYEE);
			pst.setLong(1, accNo);
			payeeLogger.warn("Payee details being fetched");
			ResultSet rs = pst.executeQuery();
			payeeLogger.debug("Payee details obtained");
			while(rs.next())
			{
				payee=new PayeeTable(rs.getLong(1), rs.getLong(2), rs.getString(3));
				payeeList.add(payee); 
			}
			
		}
		catch(Exception e)
		{
			payeeLogger.fatal("Bank Exception occured");
			throw new BankException("Exception while obtaining payee details");
		}
		
		return payeeList;
	} 

}
