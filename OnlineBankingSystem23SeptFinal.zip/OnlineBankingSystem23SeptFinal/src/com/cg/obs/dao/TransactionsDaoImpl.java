package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.dto.Customer;
import com.cg.obs.dto.Transactions;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;
import com.cg.obs.util.MyStringDateUtil;
//This class contains the methods implemented for Transactions table
public class TransactionsDaoImpl implements TransactionsDao
{	
	Logger transactionLogger=null;
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	//Method to view Transactions based on date.
	@Override
	public ArrayList<Transactions> viewTransaction(LocalDate date) throws BankException {
		ArrayList<Transactions> transactionsList=new ArrayList<Transactions>();
		try {
			transactionLogger.info("viewTranscation");
			String str=date.toString();
			System.out.println("date="+str);
			
			
			
			pst=con.prepareStatement(QueryMapper.DISPLAY_DAILY_TRANSACTIONS);
			pst.setString(1, str);
			ResultSet rs=pst.executeQuery();
			transactionLogger.debug("All transactions obtained");
			System.out.println(rs.getFetchSize());

			while(rs.next())
			{
				
				transactionLogger.info("Adding new transaction in a list");
				int transId=rs.getInt(1);
				System.out.println("transId="+transId);
				String transDesc=rs.getString(2);
				LocalDate transDate=MyStringDateUtil.fromSqlToLocalDate(rs.getDate(3));
				String transType=rs.getString(4);
				double transamt=rs.getDouble(5);
				long accId=rs.getLong(6);
				Transactions tr=new Transactions(transId, transDesc, transDate, transType, transamt , accId);
				
				transactionsList.add(tr);
			}
		} catch (SQLException e) {
			transactionLogger.fatal("Bank Exception occured");
			throw new BankException("Exception while adding new transaction");
		}
		
		return transactionsList;
	}
	//Method to view transactions based on period.
	@Override
	public ArrayList<Transactions> viewTransaction(int period,
			String duration) throws BankException {
		LocalDate start = null,end = null;
		if(duration.equalsIgnoreCase("monthly"))
		{	transactionLogger.info("In view transaction on the basis of month");
			start=LocalDate.of(2019, period , 1);
			if(period==2)
				end=LocalDate.of(2019, period, 28);
			else if(period==1 || period==3 || period==5 ||period==7 || period==8 || period==10 || period==12)
				end=LocalDate.of(2019, period, 31);
			else
				end=LocalDate.of(2019, period, 30);
		}
		if(duration.equalsIgnoreCase("yearly"))
		{
			transactionLogger.info("In view transaction on the basis of month");
			start=LocalDate.of(period, 1 , 1);
			end=LocalDate.of(period, 12 , 31);
		}
		Date sqlStart=MyStringDateUtil.fromLocalToSqlDate(start);
		Date sqlEnd=MyStringDateUtil.fromLocalToSqlDate(end);
		ArrayList<Transactions> transactionsList=new ArrayList<Transactions>();
		try {
			transactionLogger.warn("adding transactions to transaction list");
			pst=con.prepareStatement(QueryMapper.DISPLAY_ALL_TRANSACTIONS);
			pst.setDate(1, sqlStart);
			pst.setDate(2, sqlEnd);
			ResultSet rs=pst.executeQuery();
			transactionLogger.debug("All transactions obtained");
			while(rs.next())
			{
				int transId=rs.getInt(1);
				String transDesc=rs.getString(2);
				LocalDate transDate=MyStringDateUtil.fromSqlToLocalDate(rs.getDate(3));
				String transType=rs.getString(4);
				double transamt=rs.getDouble(5);
				long accId=rs.getLong(6);
				Transactions tr=new Transactions(transId, transDesc, transDate, transType, transamt , accId);
				transactionsList.add(tr);
			}
		} catch (SQLException e) {
			throw new BankException("Exception while obtaining transactions");
		}
		
		return transactionsList;
	}
	//Methods to view mini statement based on accNo.
	public ArrayList<Transactions> viewMini(long accNo) throws BankException {		
		ArrayList<Transactions> al = new ArrayList<>();			
			try {
				transactionLogger.info("View Mini Statement");
				pst=con.prepareStatement(QueryMapper.MINI_STATEMENT);
				pst.setLong(1, accNo);
				ResultSet rs=pst.executeQuery();
				transactionLogger.info("fetching mini statemenmt on the basis of account number");
						while(rs.next())
						{
							int id = rs.getInt(1);
							String discription = rs.getString(2);
							Date date=rs.getDate(3);
							String type = rs.getString(4);
							int amount = rs.getInt(5);
							long accn = rs.getLong(6);						
							al.add(new Transactions(id, discription,MyStringDateUtil.fromSqlToLocalDate(date), type,amount,accn));
							
						}
			} catch (SQLException e) {
				transactionLogger.fatal("Bank Exception occured");
				throw new BankException("Exception while obtaining Mini Statement");
			}
		
		return al;
	}
	//Method to view detailed statement based on account number and date.
	public ArrayList<Transactions> viewDetailed(long accNo,LocalDate startDate,LocalDate endDate) throws BankException {		
		ArrayList<Transactions> al = new ArrayList<>();
		System.out.println(startDate.toString());
		System.out.println(endDate.toString());
		transactionLogger.info("View detailed Statement");
			try {
				pst=con.prepareStatement(QueryMapper.DETAILED_STATEMENT);
			pst.setLong(1, accNo);
			pst.setString(2, startDate.toString());
			pst.setString(3, endDate.toString());
			ResultSet rs=pst.executeQuery();
			transactionLogger.info("fetching detailed statement on the basis of account number");
						while(rs.next())
						{
							
							System.out.println("hello");
							int id = rs.getInt(1);
							String discription = rs.getString(2);
							Date date=rs.getDate(3);
							String type = rs.getString(4);
							int amount = rs.getInt(5);
							long accn = rs.getLong(6);
							al.add(new Transactions(id, discription,MyStringDateUtil.fromSqlToLocalDate(date), type,amount,accn));
							
						}
			} catch (SQLException e) {
				transactionLogger.fatal("Bank Exception occured");
				throw new BankException("Exception while obtainig detailed statements");
			}
		
		return al;
	}
	//method to fetch data based on user_id
		public Customer getData(long uid) throws BankException {
		Customer e2=null;
		try {
			transactionLogger.info("Fetching customer data");
			long acc=0;
			PreparedStatement pst1=con.prepareStatement(QueryMapper.FETCH_ACCID);
			pst1.setLong(1, uid);
			ResultSet rs1=pst1.executeQuery();
			transactionLogger.debug("Customer data obtained");
			if(rs1.next()) {
				acc=rs1.getLong(1);
			}
			pst=con.prepareStatement(QueryMapper.FETCH_DATA);
			pst.setLong(1, acc);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				
				e2 = new Customer(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),rs.getLong(6));
									}
		
		} catch (SQLException e) {
			transactionLogger.fatal("Bank Exception occured");
			throw new BankException("Exception while fetching customer data");
		}
		return e2;
	}
		//Method to add transaction
		public String addTransaction(long debitAcc, String payeeNickName, int amt, String tranPwd)throws BankException
		{	
			transactionLogger.info("Adding new transaction");
			String pwd="";
			int bal = 0;
			int dataInsertedBal1 = 0;
			int dataInserted = 0;
			long payeeAcc = 0;
			LocalDate today = LocalDate.now();
			String tod=today.toString();
			java.sql.Date sqlToday = java.sql.Date.valueOf(today);
			try
			{
				pst = con.prepareStatement(QueryMapper.GET_PWD_BY_ID);
				pst.setLong(1, debitAcc);
				ResultSet rs = pst.executeQuery();
				while(rs.next())
				{
					pwd = rs.getString(1);
				}
				if(tranPwd.equals(pwd))
				{
					pst = con.prepareStatement(QueryMapper.GET_BALANCE);
					pst.setLong(1, debitAcc);
					rs = pst.executeQuery();
					while(rs.next())
					{
						bal= rs.getInt(1);
					}
					
					if(bal>=amt)
					{
						transactionLogger.info("Performing transfer");
						bal = bal - amt;
						pst = con.prepareStatement(QueryMapper.UPDATE_BALANCE);
						pst.setInt(1, bal);
						pst.setLong(2, debitAcc);
						dataInsertedBal1 = pst.executeUpdate();
						pst = con.prepareStatement(QueryMapper.GET_PAYEE_BY_NAME);
						pst.setString(1, payeeNickName);
						rs = pst.executeQuery();
						while(rs.next())
						{
							payeeAcc = rs.getLong(2);
						}
						pst = con.prepareStatement(QueryMapper.ADD_TRANSFER);
						pst.setLong(1,debitAcc);
						pst.setLong(2,payeeAcc);
						pst.setDate(3,sqlToday);
						pst.setInt(4,amt);
						dataInserted = pst.executeUpdate();
						
						pst = con.prepareStatement(QueryMapper.ADD_TRANSACTION);
						pst.setString(1,"Account debited");
						pst.setString(2,tod);
						pst.setString(3,"D");
						pst.setInt(4,amt);
						pst.setLong(5,debitAcc);
						dataInserted = pst.executeUpdate();
						
						pst = con.prepareStatement(QueryMapper.ADD_TRANSACTION);
						pst.setString(1,"Account credited");
						pst.setString(2,tod);
						pst.setString(3,"C");
						pst.setInt(4,amt);
						pst.setLong(5,payeeAcc);
						dataInserted = pst.executeUpdate();
						
					}
					else
					{
						transactionLogger.warn("Insufficient Balance");
						transactionLogger.fatal("Bank Exception occured");
						throw new BankException("Insufficient balance!");
					}
				}
				else
				{
					throw new Exception("Password is incorrect.");
				}
				
			}
			catch(Exception e)
			{
				transactionLogger.error("Bankexception");
				throw new BankException(e.getMessage());
			}
			
			if(dataInserted>0 && dataInsertedBal1>0)
			{
				return "Transaction successful!";
			}
			else
				return "Transaction unsuccessful!";
		
		}
		//Method to validate debit limit
		@Override
		public boolean debitLimitValueCheck(long fromAccNo, int amt)
				throws BankException {
			LocalDate today = LocalDate.now();
			java.sql.Date sqlToday = java.sql.Date.valueOf(today);
			transactionLogger.info("Checking debitLimit");
			int debitLimit = 1000000;
			try {

				System.out.println("date="+sqlToday);				
				pst=con.prepareStatement(QueryMapper.GET_TODAY_TRANSACTIONS);
				pst.setDate(1,sqlToday);
				pst.setLong(2, fromAccNo);
				ResultSet rs=pst.executeQuery();
				transactionLogger.debug("Obtaining daily transaction");
				System.out.println(rs.getFetchSize());
				while(rs.next())
				{					
					int transAmt=rs.getInt(1);
					debitLimit -= transAmt;
				}
				if((debitLimit-amt)<0)
					return false;
				else 
					return true;
			} catch (SQLException e) {
				transactionLogger.fatal("Bank Exception occured");
				throw new BankException("SQLException in debitLimitCheck");
			}

		}
		public TransactionsDaoImpl() {
			transactionLogger= Logger.getLogger(Transactions.class);
		    PropertyConfigurator.configure("log4j.properties");
		}
	
}
