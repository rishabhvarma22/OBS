package com.cg.obs.test;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.obs.dao.TransactionsDaoImpl;
import com.cg.obs.dto.Transactions;
import com.cg.obs.exception.BankException;

import junit.framework.Assert;
//A JUnit Test class for transactionDao
public class ViewMiniStatementTest {

	static TransactionsDaoImpl transactionDao = null;
	
	@BeforeClass
	public static void setUp()
	{
		transactionDao = new TransactionsDaoImpl();

	}
	
	@AfterClass
	public static void atEnd()
	{
		System.out.println("Login function is tested successfully");
	}
	
	@Before
	public void befTest()
	{
		System.out.println("Test starts");
	}
	
	@After
	public void aftTest()
	{
		System.out.println("Test ends");
	}
	
	@Test
	public void viewMiniStatementTestPass() throws BankException
	{
		try {
			ArrayList<Transactions> allTransactions = transactionDao.viewMini(1000009);	
			Assert.assertTrue(allTransactions.size()>0);
		} catch (BankException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void viewMiniStatementTestFail() throws BankException
	{
		try {
			ArrayList<Transactions> allTransactions = transactionDao.viewMini(1000);	
			Assert.assertFalse(allTransactions.size()>0);
		} catch (BankException e) {
			
			e.printStackTrace();
		}
	}
}
