package com.cg.obs.service;

import java.util.HashMap;

import com.cg.obs.exception.BankException;
//Interface for Service Tracker Service
public interface ServiceTrackerService {

	public int requestCheque(long accNo) throws BankException; 
	public String searchByServNo(int reqNo) throws BankException; 
	public HashMap<Integer,String> searchByAccNo(long accNo) throws BankException;
	public HashMap<Integer, String> searchByRequestNo(int serNum, long accNo)throws BankException;	
}
